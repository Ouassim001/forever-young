for time in range(1,12):
    print(f'The time is {time}PM')

print("the time is 12am")

for time2 in range(1,12):
    print(f'The time is {time2}AM')

print("the time is 12pm")

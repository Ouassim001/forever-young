import time
s = int(input("welke tafel wil je weten? "))

for i in range(1,11):
    print(i * s)


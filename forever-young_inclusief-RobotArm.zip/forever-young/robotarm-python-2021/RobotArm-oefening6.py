from RobotArm import RobotArm

robotArm = RobotArm('exercise 6')

# Jouw python instructies zet je vanaf hier:
robotArm.moveRight();
robotArm.moveRight();
robotArm.moveRight();
robotArm.moveRight();
robotArm.moveRight();
robotArm.moveRight();
robotArm.moveRight();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();
robotArm.moveLeft();
robotArm.moveLeft();
robotArm.grab();
robotArm.moveRight();
robotArm.drop();

robotArm.wait()